import { z } from 'zod';

const envSchema = z.object({
  VITE_REPLICATE_API_TOKEN: z.string().min(1, 'Replicate API token is required'),
});

export function validateEnv() {
  const parsed = envSchema.safeParse({
    VITE_REPLICATE_API_TOKEN: import.meta.env.VITE_REPLICATE_API_TOKEN,
  });

  if (!parsed.success) {
    throw new Error(
      'Missing environment variables. Please create a .env file with the required variables:\n' +
      parsed.error.errors.map(err => `- ${err.path}: ${err.message}`).join('\n')
    );
  }

  return parsed.data;
}

export function getEnvVar(key: keyof z.infer<typeof envSchema>): string {
  const env = validateEnv();
  return env[key];
}