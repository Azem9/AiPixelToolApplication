import { useState } from 'react';
import Replicate from 'replicate';
import type { GenerationResult } from '../types/image';
import { getEnvVar } from '../utils/env';

export function useImageGeneration() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateImage = async (prompt: string) => {
    setIsLoading(true);
    setError(null);

    try {
      let apiToken: string;
      
      try {
        apiToken = getEnvVar('VITE_REPLICATE_API_TOKEN');
      } catch (err) {
        setError('Please set up your Replicate API token in the .env file');
        throw err;
      }

      if (apiToken === 'your_replicate_api_token_here') {
        const error = 'Please replace the default API token with your actual Replicate API token';
        setError(error);
        throw new Error(error);
      }

      const replicate = new Replicate({
        auth: apiToken,
      });

      const output = await replicate.run(
        "stability-ai/sdxl:39ed52f2a78e934b3ba6e2a89f5b1c712de7dfea535525255b1aa35c5565e08b",
        {
          input: {
            prompt,
            negative_prompt: "low quality, blurry, distorted",
            num_outputs: 1
          }
        }
      ) as GenerationResult;

      if (!output?.output?.[0]) {
        throw new Error('No image was generated. Please try again.');
      }

      return output.output[0];
    } catch (err) {
      let errorMessage: string;
      
      if (err instanceof Error) {
        if (err.message.includes('401')) {
          errorMessage = 'Invalid API token. Please check your Replicate API token.';
        } else if (err.message.includes('429')) {
          errorMessage = 'Rate limit exceeded. Please try again later.';
        } else {
          errorMessage = err.message;
        }
      } else {
        errorMessage = 'An unexpected error occurred. Please try again.';
      }
      
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return { generateImage, isLoading, error };
}