import React from 'react';
import { Sparkles } from 'lucide-react';

export function Header() {
  return (
    <h1 className="text-3xl font-bold text-gray-900 mb-8 flex items-center gap-2">
      <Sparkles className="w-8 h-8" />
      AI Pixel Art Generator
    </h1>
  );
}