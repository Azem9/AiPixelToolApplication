import React from 'react';

interface PixelControlsProps {
  pixelSize: number;
  onPixelSizeChange: (size: number) => void;
  maxPixelSize: number;
}

export function PixelControls({ pixelSize, onPixelSizeChange, maxPixelSize }: PixelControlsProps) {
  return (
    <div className="flex items-center gap-4">
      <div className="flex-1">
        <input
          type="range"
          min="2"
          max={maxPixelSize}
          value={pixelSize}
          onChange={(e) => onPixelSizeChange(Number(e.target.value))}
          className="w-full"
        />
      </div>
      <div className="w-16 text-center">
        <span className="text-sm font-medium text-gray-600">{pixelSize}px</span>
      </div>
    </div>
  );
}