import React from 'react';
import { ImagePreview } from './ImagePreview';
import { PixelArtPreview } from './PixelArtPreview';

interface ImageSectionProps {
  imageUrl: string | null;
  isLoading: boolean;
  error: string | null;
  pixelSize: number;
}

export function ImageSection({ imageUrl, isLoading, error, pixelSize }: ImageSectionProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div>
        <h3 className="text-lg font-semibold mb-4">Original Image</h3>
        <ImagePreview
          imageUrl={imageUrl}
          isLoading={isLoading}
          error={error}
        />
      </div>

      {imageUrl && !error && !isLoading && (
        <div>
          <h3 className="text-lg font-semibold mb-4">Pixel Art Version</h3>
          <PixelArtPreview
            imageUrl={imageUrl}
            pixelSize={pixelSize}
          />
        </div>
      )}
    </div>
  );
}