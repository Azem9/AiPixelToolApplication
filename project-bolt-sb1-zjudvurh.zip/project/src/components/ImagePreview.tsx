import React from 'react';
import { Download, Loader2 } from 'lucide-react';

interface ImagePreviewProps {
  imageUrl: string | null;
  isLoading: boolean;
  error: string | null;
}

export function ImagePreview({ imageUrl, isLoading, error }: ImagePreviewProps) {
  const handleDownload = () => {
    if (!imageUrl) return;
    window.open(imageUrl, '_blank');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-100 rounded-lg">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          <p className="text-gray-600">Generating your image...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-100 rounded-lg">
        <p className="text-red-600">{error}</p>
      </div>
    );
  }

  if (!imageUrl) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-100 rounded-lg">
        <p className="text-gray-600">Enter a prompt to generate an image</p>
      </div>
    );
  }

  return (
    <div className="relative group">
      <img
        src={imageUrl}
        alt="Generated image"
        className="w-full rounded-lg shadow-lg"
      />
      <button
        onClick={handleDownload}
        className="absolute bottom-4 right-4 flex items-center gap-2 px-4 py-2 bg-white/90 text-gray-900 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <Download className="w-4 h-4" />
        Download
      </button>
    </div>
  );
}