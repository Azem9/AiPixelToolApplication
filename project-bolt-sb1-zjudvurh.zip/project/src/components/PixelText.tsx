import React, { useRef, useEffect } from 'react';

interface PixelTextProps {
  text: string;
  pixelSize: number;
  color: string;
  backgroundColor: string;
}

export function PixelText({ text, pixelSize, color, backgroundColor }: PixelTextProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size based on text length
    const fontSize = pixelSize * 5;
    ctx.font = `${fontSize}px monospace`;
    const metrics = ctx.measureText(text);
    const textHeight = fontSize;
    
    canvas.width = metrics.width;
    canvas.height = textHeight;

    // Draw text
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.font = `${fontSize}px monospace`;
    ctx.fillStyle = color;
    ctx.textBaseline = 'top';
    ctx.fillText(text, 0, 0);

    // Get image data
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw pixels
    for (let y = 0; y < canvas.height; y += pixelSize) {
      for (let x = 0; x < canvas.width; x += pixelSize) {
        const index = (y * canvas.width + x) * 4;
        if (data[index + 3] > 128) { // If pixel is visible
          ctx.fillStyle = color;
          ctx.fillRect(x, y, pixelSize, pixelSize);
        }
      }
    }
  }, [text, pixelSize, color, backgroundColor]);

  return <canvas ref={canvasRef} className="border border-gray-300 rounded-lg" />;
}