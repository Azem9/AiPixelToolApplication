import React, { useEffect, useRef } from 'react';
import { Download } from 'lucide-react';
import { pixelateImage } from '../utils/pixelate';

interface PixelArtPreviewProps {
  imageUrl: string;
  pixelSize: number;
}

export function PixelArtPreview({ imageUrl, pixelSize }: PixelArtPreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    pixelateImage(canvas, imageUrl, pixelSize);
  }, [imageUrl, pixelSize]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = 'pixel-art.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div className="relative group">
      <canvas
        ref={canvasRef}
        className="w-full rounded-lg shadow-lg bg-gray-100"
      />
      <button
        onClick={handleDownload}
        className="absolute bottom-4 right-4 flex items-center gap-2 px-4 py-2 bg-white/90 text-gray-900 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <Download className="w-4 h-4" />
        Download Pixel Art
      </button>
    </div>
  );
}