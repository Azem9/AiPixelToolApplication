import React, { useState } from 'react';
import { Sparkles, Grid } from 'lucide-react';
import { PromptInput } from './components/PromptInput';
import { ImagePreview } from './components/ImagePreview';
import { PixelControls } from './components/PixelControls';
import { useImageGeneration } from './hooks/useImageGeneration';
import { PixelArtPreview } from './components/PixelArtPreview';
import { Header } from './components/Header';
import { ImageSection } from './components/ImageSection';

export function App() {
  const [prompt, setPrompt] = useState('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [pixelSize, setPixelSize] = useState(4);
  const { generateImage, isLoading, error } = useImageGeneration();

  const handleGenerate = async () => {
    try {
      const url = await generateImage(prompt);
      setImageUrl(url);
    } catch (err) {
      console.error('Failed to generate image:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <Header />
          
          <div className="space-y-8">
            <PromptInput
              value={prompt}
              onChange={setPrompt}
              onSubmit={handleGenerate}
              disabled={isLoading}
            />

            {imageUrl && !error && !isLoading && (
              <div className="border-t border-gray-200 pt-8">
                <div className="flex items-center gap-2 mb-4">
                  <Grid className="w-5 h-5 text-gray-600" />
                  <h2 className="text-xl font-semibold text-gray-900">Pixel Art Settings</h2>
                </div>
                <PixelControls
                  pixelSize={pixelSize}
                  onPixelSizeChange={setPixelSize}
                  maxPixelSize={120}
                />
              </div>
            )}

            <ImageSection
              imageUrl={imageUrl}
              isLoading={isLoading}
              error={error}
              pixelSize={pixelSize}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;