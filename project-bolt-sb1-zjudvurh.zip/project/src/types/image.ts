export interface GenerationResult {
  status: string;
  output: string[];
}

export interface ImageGenerationProps {
  prompt: string;
  onSuccess?: (imageUrl: string) => void;
  onError?: (error: Error) => void;
}