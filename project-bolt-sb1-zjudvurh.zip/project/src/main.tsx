import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { validateEnv } from './utils/env';

const root = createRoot(document.getElementById('root')!);

// Validate environment variables on startup
try {
  validateEnv();
  root.render(
    <StrictMode>
      <App />
    </StrictMode>
  );
} catch (error) {
  root.render(
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8">
        <h1 className="text-2xl font-bold text-red-600 mb-4">Configuration Required</h1>
        <p className="text-gray-700 mb-6">
          To use this application, you need to set up your Replicate API token. Follow these steps:
        </p>
        <ol className="list-decimal list-inside space-y-2 text-gray-700 mb-6">
          <li>Create a <code className="bg-gray-100 px-2 py-1 rounded">.env</code> file in the project root</li>
          <li>Add your Replicate API token to the file:</li>
        </ol>
        <pre className="bg-gray-100 p-4 rounded-lg mb-6 overflow-x-auto">
          <code>VITE_REPLICATE_API_TOKEN=your_replicate_api_token_here</code>
        </pre>
        <p className="text-gray-700">
          You can get your API token from{' '}
          <a 
            href="https://replicate.com/account/api-tokens" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-blue-600 hover:text-blue-800"
          >
            Replicate's API tokens page
          </a>
        </p>
      </div>
    </div>
  );
}